Basic create
============

Simple EPUB3 creation.

## Start

    python create.py