Cover support
=============

Create simple EPUB3 with cover page.

## Start

    python create.py