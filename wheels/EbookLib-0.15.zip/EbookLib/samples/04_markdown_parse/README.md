# epub2markdown

This is just a simple example and not utility script you should use for converting your ebooks.

## Usage
    epub2markdown my_ebook.epub

## Dependencies

You need to install [Pandoc](http://johnmacfarlane.net/pandoc/) for this script to work.


