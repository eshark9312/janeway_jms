from distutils.core import setup

setup(
    version='0.1',
    name='dynamicsites',
    description="Host multiple sites from a single django project",
    url='https://bitbucket.org/uysrc/django-dynamicsites',
    platforms=['any'],
    packages=['dynamicsites'],
)
