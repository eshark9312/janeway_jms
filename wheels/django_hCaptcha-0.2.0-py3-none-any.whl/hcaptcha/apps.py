from django.apps import AppConfig


class HcaptchaConfig(AppConfig):
    name = 'hcaptcha'
