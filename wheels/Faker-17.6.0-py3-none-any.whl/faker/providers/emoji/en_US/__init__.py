from .. import Provider as EmojiProvider


class Provider(EmojiProvider):
    pass
