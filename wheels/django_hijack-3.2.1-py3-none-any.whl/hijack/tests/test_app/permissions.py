def allow_all(*, hijacker, hijacked):
    return True


def deny_all(*, hijacker, hijacked):
    return False
