from django.apps import AppConfig


class HijackConfig(AppConfig):
    name = "hijack"
    verbose_name = "Hijack"
