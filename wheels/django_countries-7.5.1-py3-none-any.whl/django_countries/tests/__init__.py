default_app_config = "django_countries.tests.apps.TestConfig"
