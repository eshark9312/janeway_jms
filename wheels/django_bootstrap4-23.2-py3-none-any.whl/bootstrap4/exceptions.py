class BootstrapException(Exception):
    """Any exception from this package."""


class BootstrapError(BootstrapException):
    """Any exception that is an error."""
